# WAINEX PWA (flat)
Struktura bez folderu `assets` (wszystko w root).